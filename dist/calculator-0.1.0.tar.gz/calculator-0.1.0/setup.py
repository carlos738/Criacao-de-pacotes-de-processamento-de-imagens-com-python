from setuptools import setup, find_packages

setup(
    name='calculator',
    version='0.1.0',
    author='Carlos',
    description='Uma calculadora simples em Python',
    packages=find_packages(),
    python_requires='>=3.6',
)

